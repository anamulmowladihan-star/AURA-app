
import React from 'react';

function App() {
  return (
    <div style={{fontFamily:'sans-serif', textAlign:'center', marginTop:'50px'}}>
      <h1>Welcome to AURA</h1>
      <p>Your mood, your vibe, your social space.</p>
    </div>
  );
}

export default App;
